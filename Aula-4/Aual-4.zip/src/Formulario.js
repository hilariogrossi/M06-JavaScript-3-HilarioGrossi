import { userState } from 'react';

export default function Formulario() {

    const [nome, setNome] = userState('');
    const [dnsc, setDnsc] = userState('');

    let idade = dnsc === '' ? 0 : calcularIdade();

    function calcularIdade() {
        const hoje = new Date();
        const [anoHoje, mesHoje, diaHoje] = [hoje.getFullYear(), hoje.getMonth(), hoje.getDate()];

        const dataNascimento = new Date(dnsc);
        const [anoDnsc, mesDnsc, diaDnsc] = [dataNascimento.getFullYear(), dataNascimento.getMonth(), dataNascimento.getDate()];

        return (mesHoje < mesDnsc || (mesHoje === mesDnsc && diaHoje < diaDnsc)) ? anoHoje - anoDnsc - 1 : anoHoje - anoDnsc;
        
        // if (mesHoje < mesDnsc || (mesHoje === mesDnsc && diaHoje < diaDnsc)) {
        //     return anoHoje - anoDnsc - 1;

        // } else {
        //     return anoHoje - anoDnsc;

        // }

    }

    function nomeChange(event) {
        setNome(event.target.value);

    }

    function dnscChange(event) {
        setDnsc(event.target.value);

    }

    return (
        <>
            <div className='formulario'>
                <label>
                    <span>Nome: </span>
                    <input type='text' id='nome' value={nome} onChange={nomeChange} />

                </label>

                <label>
                    <span>Data de Nascimento: </span>
                    <input type='date' id='dnsc' value={dnsc} onChange={dnscChange} />

                </label>

                <p>Idade: {idade}</p>

            </div>

            { nome && dnsc && <Cartao nome={nome} dnsc={dnsc} idade={idade} /> }

        </>

    );

}

function Cartao({ nome, dnsc, idade }) {
    return (
        <div className='cartao'>
            <p>Nome: {nome}</p>
            <p>Data de Nascimento: {dnsc}</p>
            <p>Idade: {idade}</p>

        </div>

    );

}
