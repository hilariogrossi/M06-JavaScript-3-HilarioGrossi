import {createContext} from 'react';
import {useContext} from 'react';

const ContextoDoNivel = createContext(0);

export default function Texto() {
    return (
        <Secao>
            <Hn>Título</Hn>

            <Secao>
                <Hn>Seção</Hn>
                <Hn>Seção</Hn>
                <Hn>Seção</Hn>

                <Secao>
                    <Hn>Sub-Seção</Hn>
                    <Hn>Sub-Seção</Hn>
                    <Hn>Sub-Seção</Hn>

                    <Secao>
                        <Hn>Sub-Sub-Seção</Hn>
                        <Hn>Sub-Sub-Seção</Hn>
                        <Hn>Sub-Sub-Seção</Hn>

                    </Secao>

                </Secao>

            </Secao>

        </Secao>

    );

}

function Secao({ children }) {
    const nivel = useContext(ContextoDoNivel);

    return (
        <section className="secao">
            <ContextoDoNivel.Provider value={nivel + 1}>
                {children}

            </ContextoDoNivel.Provider>

        </section>

    );

}

function Hn({ children }) {
    const nivel = useContext(ContextoDoNivel);

    switch(nivel) {
        case 1:
            return (<h1>{children}</h1>);

        case 2:
            return (<h2>{children}</h2>);

        case 3:
            return (<h3>{children}</h3>);

        case 4:
            return (<h4>{children}</h4>);
        
        case 5:
            return (<h5>{children}</h5>);
        
        case 6:
            return (<h6>{children}</h6>);

        default:
            throw Error('Nível Inválido!');

    }

}