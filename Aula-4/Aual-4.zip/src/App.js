import './App.css';
import Formulario from './Formulario';
import Sanfona from './Sanfona';
import Texto from './Texto';

function App() {
  return (
    <>
      <Formulario />
      <Sanfona />
      <Texto />

    </>

  );

}

export default App;
