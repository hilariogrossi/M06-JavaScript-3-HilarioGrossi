import { userState } from 'react';

export default function Sanfona() {

    const [painelAtivo, setPainelAtivo] = userState(0);

    return (
        <div className='cartao'>
            <h3>Desenvolvimento Web</h3>

            <Painel titulo='HTML' ativo={painelAtivo === 0} onShow={() => setPainelAtivo(0)}>
                Linguagem de marcação que define a estrutura/conteúdo das páginas web.

            </Painel>

            <Painel titulo='CCS' ativo={painelAtivo === 1} onShow={() => setPainelAtivo(1)}>
                Linguagem de marcação que define a aparência das páginas web.

            </Painel>


        </div>
        
    );

}

function Painel( {titulo, ativo, onShow,  children} ) {
    return(
        <section className='painel'>
            <h4>{titulo}</h4>

           { ativo ? (<p>{children}</p>) : (<button onClick={onShow} >Ativar</button>) }

        </section>

    );

}