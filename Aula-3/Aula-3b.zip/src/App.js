import './App.css';
import { useState } from 'react';

export default function Tabuleiro() {

  const [ proximo, setProximo ] = useState('X');

  const [ quadrados, setQuadrados ] = useState(Array(9).fill(null));

  function cliqueNoQuadrado(posicao) {

    if (calculaVencedor(quadrados) || quadrados[posicao]) {
      return;

    }

    const novosQuadrados = quadrados.slice();

    novosQuadrados[posicao] = proximo;

    setQuadrados(novosQuadrados);

    setProximo(proximo === 'X' ? 'O' : 'X');

  }

  let vencedor = calculaVencedor(quadrados);

  let status = vencedor ? 'Jogador Vencedor: ' + vencedor : 'Próximo Jogador: ' + proximo;

  return (
    <div className="tabuleiro">
      <div className='status'>{status}</div>

      <div className='linhaTabuleiro'>
        <button onClick={() => cliqueNoQuadrado(0)} className='quadrado'>{quadrados[0]}</button>
        <button onClick={() => cliqueNoQuadrado(1)} className='quadrado'>{quadrados[1]}</button>
        <button onClick={() => cliqueNoQuadrado(2)} className='quadrado'>{quadrados[2]}</button>

      </div>

      <div className='linhaTabuleiro'>
        <button onClick={() => cliqueNoQuadrado(3)} className='quadrado'>{quadrados[3]}</button>
        <button onClick={() => cliqueNoQuadrado(4)} className='quadrado'>{quadrados[4]}</button>
        <button onClick={() => cliqueNoQuadrado(5)} className='quadrado'>{quadrados[5]}</button>

      </div>

      <div className='linhaTabuleiro'>
        <button onClick={() => cliqueNoQuadrado(6)} className='quadrado'>{quadrados[6]}</button>
        <button onClick={() => cliqueNoQuadrado(7)} className='quadrado'>{quadrados[7]}</button>
        <button onClick={() => cliqueNoQuadrado(8)} className='quadrado'>{quadrados[8]}</button>

      </div>

    </div>

  );

}

function calculaVencedor(quadrados) {

  const linhas = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]

  ];

  for (let i = 0; i < linhas.length; i++) {

    const [a, b, c] = linhas[i];

    if (quadrados[a] === quadrados[b] && quadrados[b] === quadrados[c]) {
      return quadrados[a];

    }

  }

  return null;

}
