import './App.css';
import { useState } from 'react'

function App() {
  const [x, setX] = useState(0);

  function clique() {
    setX(x => x + 1);
    //setX(x => x + 1);

  }

  return (
    <div className="App">
      <button onClick={clique}>Cliquei {x} vezes.</button>

    </div>

  );

}

export default App;
