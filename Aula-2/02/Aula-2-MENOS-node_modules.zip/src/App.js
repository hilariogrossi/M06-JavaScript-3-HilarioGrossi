import './App.css';

function App() {
  return (
    <>
      <Topo titulo="Página em React" />
      <Painel conteudo="Tecnologias Web" />
    </>
  );
}

function Topo(prop) { // Ou function Topo({titulo})

  const h = new Date();
  let x = (h.getHours() > 18 || h.getHours() < 6) ? 
    (<span> 🌛</span>) :
    (<span> ☀️</span>);
    
  return (
    <div className='topo'>
      <span>{prop.titulo}</span> {/* Ou <span>{titulo}</span>  */}
      {x}
    </div>
  );
}

function Painel(prop) {

  const lista = ['HTML', 'CSS', 'JS', 'ReactJS', 'NextJS'];

  const itens = lista.map( (e,i) => <li key={i}>{e}</li> );

  function cliqueBotao(lst) {
    alert(lst.join(", "))
  }

  return (
    <div className='painel'>
      <h1>{prop.conteudo}</h1>
      <ul>
        {itens}
      </ul>
      <button onClick={() => cliqueBotao(lista)}>Clique aqui!</button>
    </div>
  );
}

export default App;
