import './App.css';
import Formulario from './Formulario';

function App() {
  return (
    <div className="App">
      <Formulario />
      
    </div>
  );
}

export default App;
