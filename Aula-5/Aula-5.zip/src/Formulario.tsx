import { userState } from 'react';

interface Pessoa {
    nome: string,
    dnsc: string

}

const ps:Array<Pessoa> = [
    { nome: 'João', dnsc: '2003/03/14' },
    { nome: 'Maria', dnsc: '2005/08/01' }

];

export default function Formulario() {

    const [pessoas, setPessoas] = userState<Array<Pessoa>>(ps);

    function addPessoa() {
        let nm = (document.getElementById('nome') as HTMLInputElement).value;
        let dn = (document.getElementById('dnsc') as HTMLInputElement).value;

        // const p:Pessoa = {
        //     nome: nm,
        //     dnsc: dn

        // };

        setPessoas([...pessoas, { nome: nm, dnsc: dn }]);

        // const novoPessoas = pessoas.slice();

        // novoPessoas.push(p);

        // setPessoas(novoPessoas);

    }

    return (
        <>
            <div className='formulario'>
                <label>
                    <span>Nome: </span>
                    <input type='text' id='nome' />

                </label>

                <label>
                    <span>Data de Nascimento: </span>
                    <input type='date' id='dnsc' />

                </label>

                <input type='button' value='ADICIONAR' onClick={(addPessoa)} />

            </div>

            { pessoas.map((p: Pessoa) => <Cartao nome={p.nome} dnsc={p.dnsc} />) }

        </>

    );

}

function Cartao({ nome, dnsc } : Pessoa) {

    function calcularIdade() : number {
        const hoje = new Date();
        const [anoHoje, mesHoje, diaHoje] = [hoje.getFullYear(), hoje.getMonth(), hoje.getDate()];

        const dataNascimento = new Date(dnsc);
        const [anoDnsc, mesDnsc, diaDnsc] = [dataNascimento.getFullYear(), dataNascimento.getMonth(), dataNascimento.getDate()];

        return (mesHoje < mesDnsc || (mesHoje === mesDnsc && diaHoje < diaDnsc)) ? anoHoje - anoDnsc - 1 : anoHoje - anoDnsc;

    }

    return (
        <div className='cartao'>
            <p>Nome: {nome}</p>
            <p>Data de Nascimento: {dnsc}</p>
            <p>Idade: { dnsc === '' ? 0 : calcularIdade() }</p>

        </div>

    );

}
