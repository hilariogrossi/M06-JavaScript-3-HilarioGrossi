import React, { useState } from 'react';

function CadastroUsuario() {

    const [ nome, setNome ] = useState('');
    const [ email, setEmail ] = useState('');
    const [ senha, setSenha ] = useState('');
    const [ usuarios, setUsuarios ] = useState([]);

    // const isValidEmail = (email) => {
    //     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    //     return emailRegex.test(email);

    // }

    // if (!isValidEmail(email)) {
    //     alert('E-mail Inválido! Por favor, insira um e-mail válido.')
    //     return;

    // }

    const adicionarUsuarios = () => {

        const novoUsuario = {
            nome: nome,
            email: email,
            senha: senha

        };

        setUsuarios([...usuarios, novoUsuario]);

        setNome('');
        setEmail('');
        setSenha('');

    };

    return (
        <div>

            <CadastroUsuario
                usuarios={usuarios}
                setUsuarios={setUsuarios}
                nome={nome}
                setNome={setNome}
                email={email}
                setEmail={setEmail}
                senha={senha}
                setSenha={setSenha}
                adicionarUsuarios={adicionarUsuarios}
                

            />
        
        </div>

    );

}

export default CadastroUsuario;
