import FirstPage from './Header';
import CadastroUsario from './CadastroUsuario';
import './css/styleInicialPage.css';

function App() {

  return (
    <div className="App">
      <FirstPage />
      <CadastroUsario />

    </div>
  );

}

export default App;
