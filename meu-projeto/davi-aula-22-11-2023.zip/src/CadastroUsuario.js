import React, { useState } from 'react';

function CadastroUsuario() {

    const [ nome, setNome ] = useState('');
    const [ email, setEmail ] = useState('');
    const [ senha, setSenha ] = useState('');

    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);

    }

    if (!isValidEmail(email)) {
        alert('E-mail Inválido! Por favor, insira um e-mail válido.')
        return;

    }

    return (
        <div>
            <form className='form-usuario'>
                <p>Nome: </p><input className='inputs-usuario' type='text' value={nome} autoFocus onChange={(e) => setNome(e.target.value)} /> <br />
                <p>E-mail: </p><input className='inputs-usuario' type='text' value={email} onChange={(e) => setEmail(e.target.value)} /> <br />
                <p>Senha: </p><input className='inputs-usuario' type='text' value={senha} onChange={(e) => setSenha(e.target.value)} /> <br />

                <button className='button-usuario' onClick={Armazenamento} type='submit'>Cadastrar</button>

            </form>
            

        </div>

    );

    function Armazenamento() {
  
        return (
            <div>
    
                <CadastroUsuario
                    nome={nome}
                    setNome={setNome}
                    email={email}
                    setEmail={setEmail}
                    senha={senha}
                    setSenha={setSenha}
    
                />
            
            </div>
        
        );
  
    }

}

export default CadastroUsuario;
