import FirstPage from './Header';
import './css/styleInicialPage.css';

function App() {
  return (
    <div className="App">
      <FirstPage />

    </div>
  );
}

export default App;
