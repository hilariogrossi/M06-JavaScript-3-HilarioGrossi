import Header from './Header';
import CadastroUsuario from './CadastroUsuario';
import './css/styleInicialPage.css';

function FirstPage() {

  return (
    <div className="App">
      <Header />
      <CadastroUsuario />

    </div>
  );

}

export default FirstPage;
