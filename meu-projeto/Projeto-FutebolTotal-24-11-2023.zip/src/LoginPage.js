import React from 'react';
import ReactDOM from 'react-dom/client';
import Header from './Header';
import CadastroUsuario from './CadastroUsuario';
import './css/styleInicialPage.css';

const root_1 = ReactDOM.createRoot(document.getElementById('root-1'));

root_1.render(
   <Header />,
   <CadastroUsuario />

);
