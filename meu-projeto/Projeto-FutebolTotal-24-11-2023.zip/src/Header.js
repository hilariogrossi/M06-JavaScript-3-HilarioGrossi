import React from 'react';
import boladefogo from './images/boladefogo.png'
import lupa from "./images/lupa.png"
import pipeline from "./images/pipeline.png"

export default function Header() {
    return (
        <div>
            <nav id="cabecalho">
                <a href="./index.html" className="logo">
                    <img src={boladefogo} alt="bola" />
                    <p className="frase">FutebolTotal</p>
                </a>

                <span className="span_1">
                    <a href="#">Partidas</a>

                </span>

                <span className="span_1">
                    <a href="#">Times</a>

                </span>

                <span className="span_1">
                    <a href="#">Competições</a>

                </span>

                <span className="span_1">
                    <a href="#"><img id="lupa" src={lupa} alt="Lupa" /></a>

                </span>

                <span className="span_1">
                    <img id="pipeline" src={pipeline} alt="Pipe Line" />

                </span>

                <span className="span_1">
                    <a href="#"><div className="fas fa-cog" id="menu-btn"></div></a>

                </span>

                <span className="span_1">
                    <a href="./loginPage.html" className="btn cadastro" target='_blank'>Cadastre-se</a>

                </span>

                <span className="span_1">
                    <a href="./loginPage.html" className="btn entrar" target='_blank'>Entrar</a>

                </span>

            </nav>

        </div>

    );

}
