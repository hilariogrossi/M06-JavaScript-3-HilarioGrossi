import React from 'react';
import ReactDOM from 'react-dom/client';
import FirstPage from './FirstPage';
import CadastroUsuario from './CadastroUsuario';

const root = ReactDOM.createRoot(document.getElementById('root'));

const x = 0;

if (x === 0) {
    root.render(
        <FirstPage />

    );

} else if (x === 1) {
    root.render (
        <CadastroUsuario />

    );

}
