import React from "react";

export default function BodyFirstPage() {
    return (
        <div className="noticias">
            <div className="noticias-row">
              <div className="noticia_1">
                <iframe src="https://onefootball.com/en/home"></iframe>
        
              </div>

              <div className="noticia_2">
                <iframe src="https://www.api-football.com/"></iframe>

              </div>

            </div>

            <div className="noticias-row">
              <div className="noticia_3">
                <iframe src="https://ge.globo.com/futebol/futebol-internacional/"></iframe>

              </div>

              <div className="noticia_4">
                <iframe src="http://hilariogrossi.codefico1.software/Captura_de_tela_de_2023-10-20_15-28-04.png"></iframe>

              </div>

            </div>

            <div className="noticias-row">
              <div className="noticia_1">
                <iframe src="https://ge.globo.com/futebol/times/flamengo/noticia/2023/10/24/flamengo-avanca-em-negociacao-por-renovacao-com-gabigol-ate-2028.ghtml"></iframe>
        
              </div>

              <div className="noticia_2">
                <iframe src="https://www.api-football.com/"></iframe>

              </div>

            </div>

            <div className="noticias-row">
              <div className="noticia_3">
                <iframe src="https://ge.globo.com/futebol/futebol-internacional/"></iframe>

              </div>

              <div className="noticia_4">
                <iframe src="http://hilariogrossi.codefico1.software/Captura_de_tela_de_2023-10-20_15-28-04.png"></iframe>

              </div>

            </div>

        </div>

        

    );

}
