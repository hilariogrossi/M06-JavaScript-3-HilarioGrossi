import Header from './Header';
import BodyFirstPage from './BodyFirstPage';
import './css/styleInicialPage.css';

function FirstPage() {

  return (
    <div className="App">
      <Header />
      <BodyFirstPage />

    </div>
  );

}

export default FirstPage;
