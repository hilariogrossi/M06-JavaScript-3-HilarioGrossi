import React, { useState } from 'react';

function CadastroUsuario() {

    const [ nome, setNome ] = useState('');
    const [ email, setEmail ] = useState('');
    const [ senha, setSenha ] = useState('');
    const [dadosCadastrados, setDadosCadastrados] = useState(null);

    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);

    };

    const lidarComCadastro = (event) => {
        event.preventDefault();

        if (!isValidEmail(email)) {
            alert('E-mail Inválido! Por favor, insira um e-mail válido.')
            return;
    
        }

        console.log('Dados a serem armazenados: ', { nome, email, senha });

        setDadosCadastrados({ nome, email, senha });

        setNome('');
        setEmail('');
        setSenha('');

    }

    return (
        <div>
            <form className='form-usuario' onSubmit={lidarComCadastro}>
                <p>Nome: </p><input className='inputs-usuario' type='text' value={nome} autoFocus onChange={(e) => setNome(e.target.value)} /> <br />
                <p>E-mail: </p><input className='inputs-usuario' type='text' value={email} onChange={(e) => setEmail(e.target.value)} /> <br />
                <p>Senha: </p><input className='inputs-usuario' type='text' value={senha} onChange={(e) => setSenha(e.target.value)} /> <br />

                <button className='button-usuario'type='submit'>Cadastrar</button>

            </form>

            {dadosCadastrados && (
                <div id='dados-cadastrados'>
                    <h2>Dados Cadastrados:</h2>
                    <p>Nome: {dadosCadastrados.nome}</p>
                    <p>E-mail: {dadosCadastrados.email}</p>
                    <p>Senha: {dadosCadastrados.senha}</p>

                </div>

            )}
            

        </div>

    );
  
}

export default CadastroUsuario;
