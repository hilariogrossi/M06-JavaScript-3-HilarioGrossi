import React from 'react';
import FutebolTotal from "./images/FutebolTotal.webp"
import lupa from "./images/lupa.png"
import pipeline from "./images/pipeline.png"
import engrenagem from "./images/engrenagem.svg"

function FirstPage() {
    return (
        <>
            <Cabecalho />

        </>
        
    );

}

function Cabecalho() {
    return (
        <div>
            <nav id="cabecalho">
                <a href="#"><img id="image_1" src={FutebolTotal} /></a>

                <span className="span_1">
                    <a href="#">Partidas</a>

                </span>

                <span className="span_1">
                    <a href="#">Times</a>

                </span>

                <span className="span_1">
                    <a href="#">Competições</a>

                </span>

                <span className="span_1">
                    <a href="#"><img id="lupa" src={lupa} alt="Lupa" /></a>

                </span>

                <span className="span_1">
                    <img id="pipeline" src={pipeline} alt="Pipe Line" />

                </span>

                <span className="span_1">
                    <a href="#"><img id="engrenagem" src={engrenagem} alt="Configurações" /></a>

                </span>

                <span className="span_1">
                    <a href="#" className="btn cadastro">Cadastre-se</a>

                </span>

                <span className="span_1">
                    <a href="#" className="btn entrar">Entrar</a>

                </span>

            </nav>

        </div>

    );

}


export default FirstPage;