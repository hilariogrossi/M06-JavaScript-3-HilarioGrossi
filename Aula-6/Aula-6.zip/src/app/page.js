import Image from 'next/image'
import styles from './page.module.css'
import Link from 'next/link';

export default function Home() {
  return (
    <div className={styles.pagina}>
      <div className={styles.caixa}>
        <a href='http://codefico.com.br' target='_blank'>
          <Image 
            src='/images/codefico.png' 
            alt='Codefico' 
            height={150} 
            width={300} />

        </a>

      </div>

      <div className={styles.caixa}>
        <Link href='/sanfona'>Sanfona</Link>

      </div>

      <div className={styles.caixa}>
        <Link href='/sanfona'>Sanfona</Link>

      </div>

      <div className={styles.caixa}>
        <Link href='/sanfona'>Sanfona</Link>

      </div>

    </div>
    
  )
}
