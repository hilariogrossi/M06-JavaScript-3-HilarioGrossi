'use client'

import { useState } from "react";
import Link from "next/link";
import styles from "./page.module.css";
import Painel from "../../../components/painel";

export default function Sanfona() {

  const [painelAtivo, setPainelAtivo] = useState(0);

  return (
    <div className={styles.sanfona}>
      <h3>Desenvolvimento Web</h3>

      <Painel
        titulo="HTML"
        ativo={painelAtivo === 0}
        onShow={() => setPainelAtivo(0)}
      >
        Linguagem de marcação que define a estrutura/conteúdo das páginas web.

      </Painel>

      <Painel
        titulo="CSS"
        ativo={painelAtivo === 1}
        onShow={() => setPainelAtivo(1)}
      >
        Linguagem de marcação que define a aparência das páginas web.

      </Painel>

      <div className={styles.retorno}>
        <Link href="/">Voltar</Link>
      </div>

    </div >

  );

}