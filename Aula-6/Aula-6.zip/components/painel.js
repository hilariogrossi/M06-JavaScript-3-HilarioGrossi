import styles from './painel.module.css';

export default function Painel({ titulo, ativo, onShow, children }) {
  return (
    <section className={styles.painel}>

      <h4>{titulo}</h4>

      {ativo ?
        (<p>{children}</p>) :
        (<button onClick={onShow}>Ativar</button>)
        
      }

    </section>

  );

}